#include <bits/stdc++.h>
using namespace std;

const int VERTEX = 62;
const int COLOUR = 4;

struct Node
{
    int color = 0; // ��ǰ��ɫ
    int degree = 0;
    int leftColours = COLOUR; // ʣ�������ɫ��
    bitset<COLOUR + 1> used;  // used[c] = true ��ʾ��ɫ c ������
};

// vector<Node> nodes(VERTEX);
Node nodes[VERTEX];
vector<int> connected[VERTEX]; // �ڽӱ�

int sum = 0;
clock_t start_time;

void read()
{
    ifstream ifs("planar_fixed180_62nodes.txt");
    char c;
    int u, v;
    while (ifs >> c >> u >> v)
    {
        --u;
        --v;
        connected[u].push_back(v);
        connected[v].push_back(u);
        nodes[u].degree++;
        nodes[v].degree++;
    }
    ifs.close();
}

int select_node()
{
    int min_left = COLOUR + 1, max_deg = -1, idx = -1;
    for (int i = 0; i < VERTEX; ++i)
    {
        if (nodes[i].color != 0)
            continue;
        if (nodes[i].leftColours < min_left ||
            (nodes[i].leftColours == min_left && nodes[i].degree > max_deg))
        {
            min_left = nodes[i].leftColours;
            max_deg = nodes[i].degree;
            idx = i;
        }
    }
    return idx;
}

void dfs(int num)
{
    if (num == VERTEX)
    {
        sum++;
        if (sum == 1 || sum % 10000000 == 0)
        {
            cout << "�ҵ�����: " << sum
                 << "����ʱ: " << (clock() - start_time) * 1000.0 / CLOCKS_PER_SEC << " ms" << endl;
        }
        return;
    }

    int u = select_node();
    if (u == -1)
        return;

    for (int c = 1; c <= COLOUR; ++c)
    {
        if (nodes[u].used[c])
            continue;

        nodes[u].color = c;
        vector<pair<int, int>> changed;
        bool valid = true;

        for (int v : connected[u])
        {
            if (nodes[v].color == 0 && !nodes[v].used[c])
            {
                nodes[v].used[c] = true;
                nodes[v].leftColours--;
                changed.emplace_back(v, c);

                // Forward checking
                if (nodes[v].leftColours == 0)
                {
                    valid = false;
                    break;
                }
            }
        }

        if (valid)
        {
            dfs(num + 1);
        }

        // �ָ�״̬
        for (auto it = changed.begin(); it != changed.end(); ++it)
        {
            int v = it->first;
            int clr = it->second;
            nodes[v].used[clr] = false;
            nodes[v].leftColours++;
        }

        nodes[u].color = 0;
    }
}

int main()
{
    read();
    start_time = clock();
    // int first = select_node(); // ���õ�һ��
    int first = 42;
    nodes[first].color = 1; // ��������ɫ��ѯ
    for (int v : connected[first])
    {
        if (!nodes[v].used[1])
        {
            nodes[v].used[1] = true;
            nodes[v].leftColours--;
        }
    }
    dfs(1); // �Ѿ�Ⱦɫ��һ������
    // dfs(0);
    cout << "�ܹ��ҵ� " << sum * COLOUR << " ���⡣" << endl; // ��ɫ��ѯҪ*4
    cout << "�ܺ�ʱ: " << (clock() - start_time) * 1000.0 / CLOCKS_PER_SEC << " ms" << endl;
    return 0;
}
