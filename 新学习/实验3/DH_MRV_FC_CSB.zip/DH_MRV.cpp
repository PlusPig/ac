#include <bits/stdc++.h>
using namespace std;

const int VERTEX = 450;
const int COLOUR = 5;

struct Node
{
    int color = 0; // ��ʾ��ǰȾɫ״̬
    int degree = 0;
    int leftColours = COLOUR;
    bitset<COLOUR + 1> used; // used[c] = true ��ʾ��������ɫ c
    // ��ʾ��Χ�����Ѿ��ù�
};

vector<Node> nodes(VERTEX);
vector<int> connected[VERTEX]; // �ڽӱ�

int sum = 0;
clock_t start_time;

void read()
{
    ifstream ifs("le450_5a.txt");
    char c;
    int u, v;
    while (ifs >> c >> u >> v)
    {
        --u;
        --v;
        connected[u].push_back(v);
        connected[v].push_back(u);
        nodes[u].degree++;
        nodes[v].degree++;
    }
    ifs.close();
}

int select_node()
{
    int min_left = COLOUR + 1, max_deg = -1, idx = -1;
    for (int i = 0; i < VERTEX; ++i)
    {
        if (nodes[i].color != 0)
            continue;
        if (nodes[i].leftColours < min_left ||
            (nodes[i].leftColours == min_left && nodes[i].degree > max_deg))
        {
            min_left = nodes[i].leftColours;
            max_deg = nodes[i].degree;
            idx = i;
        }
    }
    return idx;
}

void dfs(int num)
{
    if (num == VERTEX)
    {
        sum++;
        if (sum == 1 || sum % 100 == 0)
        {
            cout << "�ҵ�����: " << sum
                 << "����ʱ: " << (clock() - start_time) * 1000.0 / CLOCKS_PER_SEC << " ms" << endl;
        }
        return;
    }

    int u = select_node();
    if (u == -1)
        return;

    for (int c = 1; c <= COLOUR; ++c)
    {
        if (nodes[u].used[c])
            continue;

        nodes[u].color = c;
        vector<pair<int, int>> changed;

        for (int v : connected[u])
        {
            if (nodes[v].color == 0 && !nodes[v].used[c]) // ûȾɫ����������ɫ����
            {
                nodes[v].used[c] = true;
                nodes[v].leftColours--;
                changed.emplace_back(v, c);
            }
        }

        dfs(num + 1);

        for (auto it = changed.begin(); it != changed.end(); ++it)
        {
            int v = it->first;
            int clr = it->second;
            nodes[v].used[clr] = false;
            nodes[v].leftColours++;
        }

        nodes[u].color = 0;
    }
}

int main()
{
    read();
    start_time = clock();
    dfs(0);
    cout << "�ܹ��ҵ� " << sum << " ���⡣" << endl;
    cout << "�ܺ�ʱ: " << (clock() - start_time) * 1000.0 / CLOCKS_PER_SEC << " ms" << endl;
    return 0;
}
